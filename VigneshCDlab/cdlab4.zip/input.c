#include <stdio.h>
#include <life.h>

int n;		// I'm global, bitches

int doSomeMath(int x, int y)
{
	int sum;
	sum = x + y;
	printf("Helllloooooo\n");
}

char doSomeEnglish(int z, char c)
{
	c = c * z * z * z * z * z; 		//Coz y not?
	printf("Sup niggs?");
}

double fun(int x, double a){

	int a, b, ten;
	double d; 			// LOL

	printf("How beautiful is this code from 10 to 10?");
	scanf("%d", &ten);
	return d;
}

void empty(){			//Just like my life without you

}

int main()				//Okay, I'm bored
{
	int a,b;
	double d;
	char c;
}
